<?php 
session_start();
include_once 'include/header.php';
include_once 'include/config.php';

// Delete appointment if delete request is sent
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $delete_query = "DELETE FROM appointments WHERE app_id = $delete_id";
    mysqli_query($conn, $delete_query);
    header("Location: appointment.php");
    exit;
}

// Get all appointments with doctor and patient info
$query = "SELECT a.app_id, a.appointment_date, a.status,
          d.name AS doctor_name, dep.depart_name AS department,
          u.username AS patient_name, u.user_mobile AS patient_mobile
          FROM appointments a
          JOIN doctors d ON a.doctor_id = d.id
          JOIN departments dep ON d.department_id = dep.depart_id
          JOIN users u ON a.user_id = u.user_id
          ORDER BY a.appointment_date DESC";
$result = mysqli_query($conn, $query);
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Appointments Management</h1>
    </div>

    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>Patient</th>
                    <th>Contact</th>
                    <th>Doctor</th>
                    <th>Department</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= $row['app_id'] ?></td>
                    <td><?= date('M d, Y h:i A', strtotime($row['appointment_date'])) ?></td>
                    <td><?= $row['patient_name'] ?></td>
                    <td><?= $row['patient_mobile'] ?></td>
                    <td>Dr. <?= $row['doctor_name'] ?></td>
                    <td><?= $row['department'] ?></td>
                    <td>
                        <a href="?delete_id=<?= $row['app_id'] ?>" 
                           class="btn btn-sm btn-danger"
                           onclick="return confirm('Are you sure you want to delete this appointment?');">
                           Delete
                        </a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include_once 'include/footer.php'; ?>
