<?php 
include_once 'include/header.php';
include_once 'include/config.php';

// Process booking if form submitted
if (isset($_POST['book_appointment']) && isset($_POST['doctor_id'])) {
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }
    
    $doctor_id = $_POST['doctor_id'];
    $user_id = $_SESSION['user_id'];
    
    // Check if already booked
    $check_query = "SELECT app_id FROM appointments WHERE doctor_id = ? AND user_id = ?";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bind_param("ii", $doctor_id, $user_id);
    $check_stmt->execute();
    $check_stmt->store_result();
    
    if ($check_stmt->num_rows == 0) {
        $query = "INSERT INTO appointments (doctor_id, user_id) VALUES (?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ii", $doctor_id, $user_id);
        
        if ($stmt->execute()) {
            header("Location: doctors.php?booked=1");
            exit();
        } else {
            echo '<div class="alert alert-danger">Error booking appointment: ' . $conn->error . '</div>';
        }
    }
    $check_stmt->close();
}

// Process cancellation if cancel button clicked
if (isset($_POST['cancel_appointment']) && isset($_POST['doctor_id'])) {
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }

    $appointment_id = $_POST['cancel_appointment'];
    $user_id = $_SESSION['user_id'];
    $doctor_id = $_POST['doctor_id'];

    $delete_query = "DELETE FROM appointments WHERE app_id = ? AND doctor_id = ? AND user_id = ?";
    $delete_stmt = $conn->prepare($delete_query);
    $delete_stmt->bind_param("iii", $appointment_id, $doctor_id, $user_id);

    if ($delete_stmt->execute()) {
        header("Location: doctors.php?canceled=1");
        exit();
    } else {
        echo '<div class="alert alert-danger">Error canceling appointment: ' . $conn->error . '</div>';
    }

    $delete_stmt->close();
}

// Fetch all doctors with their department names
$query = "SELECT d.id, d.name, d.image, dep.depart_name 
          FROM doctors d 
          JOIN departments dep ON d.department_id = dep.depart_id";
$result = mysqli_query($conn, $query);
?>

<div class="container">
    <div class="row">
        <div class="col-12">
            <h1 class="text-center my-4">Our Doctors</h1>
        </div>
    </div>

    <div class="row">
        <?php 
        $count = 0;
        while($doctor = mysqli_fetch_assoc($result)): 
            $count++;
            if ($count % 4 == 1 && $count > 1) {
                echo '</div><div class="row">';
            }
        ?>
        <div class="col-md-3 mb-4">
            <div class="card h-100 shadow-sm">
                <?php 
                $imagePath = !empty($doctor['image']) ? 
                    str_replace('../', '', $doctor['image']) : 
                    'image/doctors/default.jpg';
                ?>
                <img class="card-img-top doctor-photo" 
                     src="<?= $imagePath ?>" 
                     alt="<?= $doctor['name'] ?>"
                     style="height: 200px; object-fit: cover; width: 100%;">
                <div class="card-body">
                    <h5 class="card-title">Department: <?= $doctor['depart_name'] ?></h5>
                    <p class="card-text">Name: <?= $doctor['name'] ?></p>
                </div>
                <div class="card-footer bg-white">
                    <?php
                    $is_booked = false;
                    $appointment_id = null;
                    if (isset($_SESSION['user_id'])) {
                        $check_query = "SELECT app_id FROM appointments 
                                        WHERE doctor_id = ? AND user_id = ?";
                        $check_stmt = $conn->prepare($check_query);
                        $check_stmt->bind_param("ii", $doctor['id'], $_SESSION['user_id']);
                        $check_stmt->execute();
                        $check_stmt->bind_result($appointment_id);
                        $is_booked = $check_stmt->fetch();
                        $check_stmt->close();
                    }

                    if ($is_booked): ?>
                        <form method="post" action="">
                            <input type="hidden" name="cancel_appointment" value="<?= $appointment_id ?>">
                            <input type="hidden" name="doctor_id" value="<?= $doctor['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-primary btn-block text-white">
                                Booked (Click to Cancel)
                            </button>
                        </form>
                    <?php else: ?>
                        <form method="post" action="">
                            <input type="hidden" name="doctor_id" value="<?= $doctor['id'] ?>">
                            <button type="submit" name="book_appointment" 
                                    class="btn btn-sm btn-outline-primary btn-block">
                                Book Appointment
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>

<?php include_once 'include/footer.php'; ?>
