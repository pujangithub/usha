<?php include_once 'include/header.php'; ?>
<div class="container-fluid bg-transparent">
    <div class="row justify-content-center">
        <div class="col-12 mt-5 py-4 px-4 bg-white">
            <div class="container shadow-lg">
                <h3>About Us</h3>
                <hr>
                <p><strong>CareFirst</strong> is a trusted health service provider dedicated to delivering quality medical care and support to individuals and families. Our mission is to provide accessible, affordable, and efficient healthcare to all.</p>
                
                <p>Founded with a vision to revolutionize healthcare in Nepal, we have built a team of compassionate professionals, modern facilities, and user-friendly online services to meet the needs of today's patients.</p>
                
                <h5>Our Vision</h5>
                <p>To become the most trusted healthcare platform, known for innovation, compassion, and patient-centered care.</p>
                
                <h5>Our Mission</h5>
                <ul>
                    <li>To provide reliable medical consultations and appointments.</li>
                    <li>To ensure convenience through technology-driven services.</li>
                    <li>To promote health education and awareness in the community.</li>
                </ul>

                <h5>Why Choose CareFirst?</h5>
                <ul>
                    <li>Experienced medical professionals</li>
                    <li>Advanced facilities and technology</li>
                    <li>24/7 patient support</li>
                    <li>Easy online appointment booking</li>
                </ul>

                <p class="mt-4">Thank you for choosing <strong>CareFirst</strong> – Your health is our priority.</p>
            </div>
        </div>
    </div>
</div>
<?php include_once 'include/footer.php'; ?>
