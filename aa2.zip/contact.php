<?php include_once 'include/header.php'; ?>
<div class="container-fluid bg-transparent">
    <div class="row justify-content-center">
        <div class="col-12 mt-5 py-4 px-4 bg-white">
            <div class="container shadow-lg">
                <h3>Contact Us</h3>
                <hr>
                <p>If you have any questions or concerns, feel free to reach out to us through the following contact details:</p>
                
                <div class="mb-3">
                    <h5>Email</h5>
                    <p><a href="mailto:info@medicare.com">info@medicare.com</a></p>
                </div>

                <div class="mb-3">
                    <h5>Phone</h5>
                    <p>+977-9800000000</p>
                </div>

                <div class="mb-3">
                    <h5>Office Hours</h5>
                    <p>Sunday - Friday: 9:00 AM - 6:00 PM<br>Saturday: Closed</p>
                </div>

                <div class="mb-3">
                    <h5>Address</h5>
                    <p>Medicare Health Services<br>Kamalpokhari, Kathmandu, Nepal</p>
                </div>

                <div class="mb-3">
                    <h5>Follow Us</h5>
                    <p>
                        <a href="https://facebook.com/medicare" target="_blank">Facebook</a> |
                        <a href="https://instagram.com/medicare" target="_blank">Instagram</a> |
                        <a href="https://twitter.com/medicare" target="_blank">Twitter</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include_once 'include/footer.php'; ?>
