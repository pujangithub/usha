<?php
session_start();
include_once 'include/config.php';

// Handle delete action first before any output
if (isset($_POST['delete'])) {
    $doctor_id = $_POST['doctor_id'];

    // Delete doctor from database
    $delete_query = "DELETE FROM doctors WHERE id = $doctor_id";
    if (mysqli_query($conn, $delete_query)) {
        header("Location: managedoctors.php"); // Redirect after deletion
        exit();
    }
}

// View the list of doctors
include_once 'include/header.php';
?>

<div class="container">
    <a href="doctorform.php" class="btn btn-primary mb-3">Add New Doctor</a>
    <h3 class="mt-4">Doctors List</h3>
    <div class="table-responsive pt-5">
        <table class="table shadow-lg table-hover table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">Doctor Id</th>
                    <th scope="col">Name</th>
                    <th scope="col">Department</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $query = "SELECT * FROM doctors";
                    $result = mysqli_query($conn, $query);
                    if (mysqli_num_rows($result) > 0) {
                        while ($doctor = mysqli_fetch_assoc($result)) {
                            // Get department name by ID (Corrected table name here)
                            $department_query = "SELECT depart_name FROM departments WHERE depart_id = '{$doctor['department_id']}'";
                            $department_result = mysqli_query($conn, $department_query);
                            $department_row = mysqli_fetch_assoc($department_result);
                            $department_name = $department_row['depart_name'];
                            
                            echo "<tr>
                                    <th scope='row'>{$doctor['id']}</th>
                                    <td>{$doctor['name']}</td>
                                    <td>{$department_name}</td>
                                    <td>
                                        <a href='doctorfulldetail.php?id={$doctor['id']}'>
                                            <button class='btn btn-info'>View Full Detail</button>
                                        </a>
                                        <form action='' method='POST' class='d-inline'>
                                            <input type='hidden' name='doctor_id' value='{$doctor['id']}'>
                                            <button type='submit' name='delete' class='btn btn-danger'>Delete</button>
                                        </form>
                                    </td>
                                  </tr>";
                        }
                    }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php
include_once 'include/footer.php';
?>
