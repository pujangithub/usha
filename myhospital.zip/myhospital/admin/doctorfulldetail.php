<?php
session_start();
include_once 'include/config.php';

// Check if the doctor ID is provided in the URL
if (isset($_GET['id'])) {
    $doctor_id = $_GET['id'];

    // Fetch the doctor's details from the database
    $query = "SELECT * FROM doctors WHERE id = $doctor_id";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $doctor = mysqli_fetch_assoc($result);

        // Fetch the department name using department_id
        $department_query = "SELECT depart_name FROM departments WHERE depart_id = '{$doctor['department_id']}'";
        $department_result = mysqli_query($conn, $department_query);
        $department_row = mysqli_fetch_assoc($department_result);
        $department_name = $department_row['depart_name'];
    } else {
        echo "Doctor not found.";
        exit();
    }
} else {
    echo "No doctor ID provided.";
    exit();
}

include_once 'include/header.php';
?>

<div class="container">
    <h3 class="mt-4">Doctor Full Details</h3>

    <!-- Doctor details -->
    <div class="card shadow-lg p-3 mb-5 bg-white rounded">
        <div class="card-body">
            <!-- Display doctor's image at top -->
            <?php if (!empty($doctor['image'])): ?>
                <div class="text-center mb-4">
                    <img src="<?= $doctor['image'] ?>" alt="Doctor's Image" class="rounded-circle doctor-photo">
                </div>
            <?php endif; ?>

            <h5 class="card-title text-center mb-4"><?= $doctor['name'] ?></h5>
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Department:</strong> <?= $department_name ?></p>
                    <p><strong>Email:</strong> <?= $doctor['email'] ?></p>
                    <p><strong>Mobile:</strong> <?= $doctor['mobile'] ?></p>
                    <p><strong>Gender:</strong> <?= $doctor['gender'] ?></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Address:</strong> <?= $doctor['address'] ?></p>
                    <p><strong>City:</strong> <?= $doctor['city'] ?></p>
                    <p><strong>Pin Code:</strong> <?= $doctor['pin_code'] ?></p>
                    <p><strong>ID Type:</strong> <?= $doctor['id_type'] ?></p>
                    <p><strong>ID Number:</strong> <?= $doctor['id_number'] ?></p>
                    <p><strong>Joined on:</strong> <?= $doctor['created_at'] ?></p>
                </div>
            </div>
        </div>
    </div>

    <a href="managedoctors.php" class="btn btn-primary">Back to Doctors List</a>
</div>

<?php include_once 'include/footer.php'; ?>
                