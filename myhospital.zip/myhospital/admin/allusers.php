<?php 
include_once 'include/config.php'; // Ensure database connection
session_start();
include_once 'include/header.php';

// Fetch all users from database
$sql = "SELECT user_id, username, user_email, role, created_at, user_mobile FROM users";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Database query failed: " . mysqli_error($conn));
}
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">User Management</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <!-- Removed Export Button -->
    </div>
</div>

<div class="table-responsive">
    <table class="table table-striped table-sm table-primary">
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Mobile</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            <?php while($user = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?= htmlspecialchars($user['user_id']) ?></td>
                <td><?= htmlspecialchars($user['username']) ?></td>
                <td><?= htmlspecialchars($user['user_email']) ?></td>
                <td><?= htmlspecialchars($user['role']) ?></td>
                <td><?= !empty($user['user_mobile']) ? htmlspecialchars($user['user_mobile']) : 'N/A' ?></td>
                <td><?= htmlspecialchars($user['created_at']) ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include_once 'include/footer.php'; ?>
