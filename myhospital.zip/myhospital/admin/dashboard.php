<?php 
session_start();
include_once 'include/header.php';
include_once 'include/config.php';

// Get statistics
$doctors = mysqli_query($conn, "SELECT COUNT(*) FROM doctors")->fetch_row()[0];
$patients = mysqli_query($conn, "SELECT COUNT(*) FROM users WHERE role='patient'")->fetch_row()[0];
$appointments = mysqli_query($conn, "SELECT COUNT(*) FROM appointments")->fetch_row()[0];
$pending = mysqli_query($conn, "SELECT COUNT(*) FROM appointments WHERE status='Pending'")->fetch_row()[0];
$departments = mysqli_query($conn, "SELECT COUNT(*) FROM departments")->fetch_row()[0];
?>

<div class="container-fluid">
    <h1 class="h2 mb-4">Hospital Dashboard</h1>
    
    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-4 mb-3">
            <div class="card text-white bg-primary h-100">
                <div class="card-body">
                    <h5 class="card-title">Doctors</h5>
                    <h2 class="card-text"><?= $doctors ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card text-white bg-success h-100">
                <div class="card-body">
                    <h5 class="card-title">Patients</h5>
                    <h2 class="card-text"><?= $patients ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card text-white bg-info h-100">
                <div class="card-body">
                    <h5 class="card-title">Departments</h5>
                    <h2 class="card-text"><?= $departments ?></h2>
                </div>
            </div>
        </div>
    </div>

    <!-- Appointments Section -->
    <div class="card mb-4">
        <div class="card-header bg-warning text-dark">
            <h5>Appointments Overview</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <h6>Total Appointments: <?= $appointments ?></h6>
                    <h6>Pending Appointments: <?= $pending ?></h6>
                </div>
                <div class="col-md-6">
                    <div class="progress">
                        <div class="progress-bar bg-success" 
                             style="width: <?= $appointments ? round(($appointments-$pending)/$appointments*100) : 0 ?>%">
                            Completed: <?= $appointments-$pending ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once 'include/footer.php'; ?>
